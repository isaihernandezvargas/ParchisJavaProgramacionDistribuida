#
# Simple Compile Script
#
rm *.class
javac *.java
java Parchessi
