import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

@SuppressWarnings("serial")
class Menu extends JPanel {

	public Menu() {
		setBackground(new Color(72, 209, 204));

		addButton(this, "Salir del juego", null, new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (areYouSure()) {
					System.exit(0);
				}
			}
		});

	}

	public void addButton(Container c, String title, ImageIcon img,
			ActionListener a) {
		JButton b = new JButton(title);
		c.add(b);
		b.addActionListener(a);
	}


	public boolean areYouSure() {
		String[] options = { "Si!", "No!" };
		String x = (String) JOptionPane.showInputDialog(null, "�Estas seguro?",
				"Parchis", JOptionPane.QUESTION_MESSAGE, null, options,
				options[0]);
		if (x == "Si!") {
			return true;
		} else {
			return false;
		}

	}
}