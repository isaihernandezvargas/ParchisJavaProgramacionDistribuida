import java.awt.AWTException;
import java.awt.Color;
//import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.awt.event.InputEvent;
//import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
class Parchessi extends JFrame implements Runnable{
	private static int turnValue;
	//private static int displayValue;
	private static int roll;
	private static int numPlayers;
	private static JFrame gameFrame;
	private static JLabel rollView;
	private static Board b;
	private static boolean rollAgain;
	private Menu m;
	private JPanel mContainer;
	private JButton rollButton;
	private JButton nextTurn;
	
	private Scanner scanner = new Scanner(System.in);
	private String ip = "192.168.0.103";
	private String ip2 = "localhost";
	private int port = 22222;
	private Thread thread;
	private Socket socket;
	private DataOutputStream dos;
	private DataInputStream dis;
	private ServerSocket serverSocket;
	public static boolean aceptado = false;
	private static boolean circle = true;
	private boolean tuTurno = false;
	
	private static int[][] posiciones = new int[][] {{0, 0}, {0, 0}, {0, 0}, {0, 0}};
	//private static int[] posiciones = new int[] {0, 0};
	private static int perdiste = 0;

	/*
	 Constructor del juego
	 */
	public Parchessi() {
		System.out.println("Introduce la IP: ");
		ip = scanner.nextLine();
		System.out.println("Introduce el puerto: ");
		port = scanner.nextInt();
		while(port < 1 || port > 65535) {
			System.out.println("Puerto invalido, introduce otro valido");
			port = scanner.nextInt();
		}
		
		
		rollAgain = false;
		turnValue = 0;
		chooseNumPlayers();
		
		if(!connect())
			initializeServer();
		
		
		
		thread = new Thread(this, "Parchessi");
		thread.start();
		
		rollButton = new JButton("Tirar dado");
		rollButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if(tuTurno) {
				Parchessi.roll();
				
				if(!circle) {
					 try {
				            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				        } catch (Exception e) {
				            /*No hacer nada*/
				        }
				}
				System.out.println("La suma de mis dados es: " + roll + "\n");
				tuTurno = false;
				
				
				
				while (rollAgain == true) {
					rollAgain = false;
					System.out
							.println("Parchessi:rollButton.addActionListener(): Roll again set to false");
					System.out
							.println("Parchessi:rollButton.addActionListener(): Rolling Again, automatically");
					System.out
							.println("Parchessi:rollButton.addActionListener(): before Roll: "
									+ roll);
					roll += rollAgain();
					System.out
							.println("Parchessi:rollButton.addActionListener():  after Roll: "
									+ roll);
				}
				Board.movePlayer(turnValue, roll);
				int ficha = Player.fichaa();
				//System.out.println("Tienes la ficha: " + ficha);
				posiciones[ficha][0] = posiciones[ficha][0] + roll;
				try {
					
					//dos.writeInt(roll);
					dos.writeInt(roll);
					dos.writeInt(ficha);
					dos.flush();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				
				repaint();
				
				Toolkit.getDefaultToolkit().sync();
				
				int res = Board.checkWin();
				if (res > -1) {
					//perder(res);
					gameHasBeenWon(res);
				}
				rollButton.setEnabled(false);
				nextTurn.setEnabled(true);
			}
				tuTurno = false;
			}
			
		});
		
		// Se debe esperar a que el otro jugador tire
		nextTurn = new JButton("Esperando...");
		nextTurn.setEnabled(false);
		nextTurn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				rollButton.setEnabled(true);
				nextTurn.setEnabled(false);
				getNextTurn();
				

			}
		});
		//System.out.println("mi turno es : " + tuTurno);
		if(tuTurno == false) {
			rollButton.setEnabled(false);
		}
		
		//tuTurno = false;
		repaint();
		Toolkit.getDefaultToolkit().sync();

		// Inicializar el tablero
		b = new Board(numPlayers);
		m = new Menu();
		m.add(rollButton);
		m.add(nextTurn);

		mContainer = new JPanel();
		rollView = new JLabel(" ");

		rollView.setBorder(new EmptyBorder(5, 5, 5, 5));
		b.setBorder(new EmptyBorder(5, 5, 5, 5));
		mContainer.add(m, "East");
		mContainer.add(rollView, "West");
		add(b, "Center");
		add(mContainer, "South");
		getContentPane().setBackground(new Color(250, 250, 250));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pack();
		setBounds(20, 20, 800, 700);// Tama�o
		setVisible(true);
		
		repaint();
		
		Toolkit.getDefaultToolkit().sync();
	}
	
	//public static void perder(int res) {
		//perdiste = 1;
	//}

	public static void gameHasBeenWon(int id) {
		//System.out.println("Perdiste tiene : " + perdiste);
				if (circle) {
					id = id +1;
				JOptionPane.showMessageDialog(null, "Felicidades jugador " + id
						+ "!!! Has ganado");
				// JOptionPane.showMessageDialog(null, "");	
				id = id -1;
				}
				else
				{
					
					JOptionPane.showMessageDialog(null, "Felicidades jugador " + id
							+ "!!! Has ganado");
					
				}
		
				perdiste = 1;
				
				System.exit(0);
		
	}


	public static void getNextTurn() {
		turnValue += 1;
		turnValue %= numPlayers;
		rollView.setText("Tu primer dado sali� con " + "y tu segundo con");
	}

	//Dado!
	public static int roll() {

		Random diceRoller = new Random();
		roll = diceRoller.nextInt(6) + 1;
		int roll2 = diceRoller.nextInt(6) + 1;

		if (roll == roll2) {
		}
		
		
		rollView.setText("Tu primer dado sali� con " + Integer.toString(roll) + " y segundo con " + Integer.toString(roll2));

		roll += roll2;
		
		return roll;
	}

	public static int rollAgain() {
		System.out.println("Parchessi:rollAgain(): entering this method");
		Random diceRoller = new Random();
		int roll1 = diceRoller.nextInt(6) + 1;
		int roll2 = diceRoller.nextInt(6) + 1;

		System.out.println("Parchessi:rollAgain(): Roll value " + roll1
				+ " and " + roll2);
		roll1 += roll2;
		return roll1;
	}

	public static void chooseNumPlayers() {
		int input = -1;
		while (input == -1) {
			input = JOptionPane.showConfirmDialog(null, 
	                "Bienvenido a nuestro juego de parchis para 2 jugadores\n�Desea comenzar un juego?", 
	                "Bienvenido", JOptionPane.DEFAULT_OPTION);
			if(input == 0) numPlayers = 1;
		}

	}
	
	public static void reset() {
		gameFrame.setVisible(false); 
		gameFrame.dispose();
		gameFrame = new Parchessi();
	}


	public static Board getBoard() {
		return b;
	}


	public static void main(String[] args) throws AWTException {
		gameFrame = new Parchessi();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			tick();
			repaint();
			if (!circle && !aceptado) {
				listenForServerRequest();
			}
		}
	
	}
	//private void checkForEnemyWin() {
		
	//}
	private void tick() {
		

		if (!tuTurno) { 
			try {
				tuTurno = true;
				int space = dis.readInt();
				int suficha = dis.readInt();
				//System.out.println("ha  tirado con "+ space + " con la ficha " + suficha);
				posiciones[suficha][1] = posiciones[suficha][1] + space;
				
				if(circle) {
					 try {
				            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				        } catch (Exception e) {
				            /*No hacer nada*/
				        }
				}
				
				System.out.println("      Status de tu rival\n" +
				"Ficha 0 con un avance de " + posiciones[0][1] + " posciones\n" + 
				"Ficha 1 con un avance de " + posiciones[1][1] + " posciones\n" +
				"Ficha 2 con un avance de " + posiciones[2][1] + " posciones\n" +
				"Ficha 3 con un avance de " + posiciones[3][1] + " posciones\n");
				rollButton.setEnabled(true);
				//JOptionPane.showMessageDialog(null, "tu rival ha tirado");
				/*if (circle) 
				Board.movePlayer(turnValue, space);
				else
					Board.movePlayer(turnValue, roll);*/
				//checkForEnemyWin();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		if(perdiste == 1) {
			JOptionPane.showMessageDialog(null, "Has perdido :0");
			System.exit(0);
		}
		
	}
	
	private void listenForServerRequest() {
		Socket socket = null;
		try {
			socket = serverSocket.accept();
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
			aceptado = true;
			System.out.println("Cliente ha sido aceptado y se ha unido");
			JOptionPane.showConfirmDialog(null, 
	                "Cliente unido", "Informacion", JOptionPane.DEFAULT_OPTION);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private boolean connect() {
		try {
			socket = new Socket(ip, port);
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
			aceptado = true;
		} catch (IOException e) {
			System.out.println("Esperando conexion...\n\n");
			return false;
		}
		System.out.println("Conectado exitosamente al servidor\n\n");
		JOptionPane.showConfirmDialog(null, 
                "Conexion exitosa", "informacion!", JOptionPane.DEFAULT_OPTION);
		return true;
	}

	private void initializeServer() {
		try {
			serverSocket = new ServerSocket(port, 1, InetAddress.getByName(ip2));
		} catch (Exception e) {
			e.printStackTrace();
		}
		circle = false;
		tuTurno = true;

	}

	
	public static boolean aceptadoo(){
		boolean regresa = aceptado;
		return regresa;
	}
	
	public static boolean circlee(){
		boolean regresa = circle;
		return regresa;
	}
	
	public static int dado(){
		return  roll;
	}
	
	public static int [][] datos(){
		return posiciones;
	}

}
